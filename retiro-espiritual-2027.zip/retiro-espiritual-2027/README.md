# Sistema de Gestão do Retiro Espiritual 2027

Aplicação web estática, responsiva e pronta para abrir no navegador ou executar via VSCode + Live Server.

## Estrutura de arquivos

```text
retiro-espiritual-2027/
├── index.html
├── login.html
├── inscricao.html
├── dashboard.html
├── perfil.html
├── css/
│   ├── styles.css
│   ├── responsive.css
│   └── components.css
├── js/
│   ├── app.js
│   ├── inscricao.js
│   ├── dashboard.js
│   ├── api.js
│   └── utils.js
├── assets/
│   └── logo.png
└── README.md
```

## Como extrair

1. Baixe o arquivo ZIP.
2. Extraia o conteúdo para uma pasta local.
3. Abra a pasta `retiro-espiritual-2027` no VSCode.

## Como executar

### Opção 1 — Navegador direto

Basta abrir o arquivo `index.html` em qualquer navegador moderno.

### Opção 2 — VSCode com Live Server

1. Instale a extensão **Live Server**.
2. Clique com o botão direito em `index.html`.
3. Selecione **Open with Live Server**.

## Funcionalidades incluídas

- Landing page com informações do evento e contador para 18/04/2026.
- Login com 5 perfis.
- Inscrição em 5 etapas com acompanhantes conforme tipo de apartamento.
- Upload opcional de comprovante (simulação local).
- Dashboard com mapa de ocupação, financeiro, refeições, veículos, relatórios e auditoria.
- Perfil do retirante com recibo, status de pagamento e troca de senha.
- Persistência em `localStorage`, sem necessidade de backend real.

## Credenciais de teste

### Equipes
- **Administrador Geral**  
  Usuário: `admin`  
  Senha: `retiro2027`

- **Equipe Financeira**  
  Usuário: `financeiro`  
  Senha: `financeiro2027`

- **Equipe Hospedagem**  
  Usuário: `hospedagem`  
  Senha: `hospedagem2027`

- **Equipe Alimentação**  
  Usuário: `alimentacao`  
  Senha: `alimentacao2027`

### Retirante
- Login por CPF ou código de inscrição.
- Exemplo demo: `RET2027-1007`
- Exemplo demo: `529.982.247-25`

## Observações técnicas

- Todos os dados demo são carregados na primeira execução.
- Para restaurar a base inicial, use o botão **Restaurar demo** no dashboard.
- O sistema simula API e banco usando `localStorage` do navegador.
- Os comprovantes não são enviados para servidor; apenas o nome do arquivo é salvo na simulação.

## Sugestão de uso

1. Abra `index.html`.
2. Faça uma inscrição em `inscricao.html`.
3. Entre em `login.html` como participante ou equipe.
4. Explore `dashboard.html` para operação administrativa.
5. Consulte `perfil.html` para ver o portal do retirante.
