window.InscricaoApp = (() => {
  const state = {
    currentStep: 1,
    proofFileName: '',
    submittedCode: ''
  };

  const init = () => {
    if (document.body.dataset.page !== 'inscricao') return;
    API.init();
    bindMasks();
    bindWizard();
    populateAccommodationOptions();
    renderCompanionFields();
    updateSummary();
  };

  const getForm = () => document.getElementById('registrationForm');

  const bindMasks = () => {
    const cpfInput = document.getElementById('cpf');
    const phoneInput = document.getElementById('phone');
    const birthInput = document.getElementById('birthDate');
    const amountPaidInput = document.getElementById('amountPaid');

    cpfInput?.addEventListener('input', () => {
      cpfInput.value = Utils.cpfMask(cpfInput.value);
    });

    phoneInput?.addEventListener('input', () => {
      phoneInput.value = Utils.phoneMask(phoneInput.value);
    });

    birthInput?.addEventListener('change', () => {
      const age = Utils.calculateAge(birthInput.value);
      document.getElementById('agePreview').textContent = age ? `${age} anos` : '—';
      updateSummary();
    });

    amountPaidInput?.addEventListener('input', updateSummary);
  };

  const bindWizard = () => {
    const form = getForm();
    if (!form) return;

    document.querySelectorAll('[data-next-step]').forEach((button) => {
      button.addEventListener('click', () => {
        const nextStep = Number(button.dataset.nextStep);
        if (!validateStep(state.currentStep)) return;
        state.currentStep = nextStep;
        renderStep();
      });
    });

    document.querySelectorAll('[data-prev-step]').forEach((button) => {
      button.addEventListener('click', () => {
        state.currentStep = Number(button.dataset.prevStep);
        renderStep();
      });
    });

    document.getElementById('accommodationType')?.addEventListener('change', () => {
      renderCompanionFields();
      updateSummary();
    });

    document.getElementById('gender')?.addEventListener('change', updateSummary);
    document.getElementById('installments')?.addEventListener('change', updateSummary);
    document.getElementById('paymentMethod')?.addEventListener('change', updateSummary);
    document.getElementById('fullName')?.addEventListener('input', updateSummary);
    document.getElementById('vehiclePlate')?.addEventListener('input', updateSummary);

    document.getElementById('proofFile')?.addEventListener('change', (event) => {
      state.proofFileName = event.target.files?.[0]?.name || '';
      document.getElementById('proofLabel').textContent = state.proofFileName || 'Clique ou arraste um arquivo de comprovante';
      updateSummary();
    });

    form.addEventListener('submit', handleSubmit);
  };

  const populateAccommodationOptions = () => {
    const select = document.getElementById('accommodationType');
    if (!select) return;
    const stock = API.getAccommodationStock();
    select.innerHTML = stock.map((item) => `
      <option value="${item.key}">${item.label} • ${Utils.currency(item.price)} • ${item.availableUnits} unidades disponíveis</option>
    `).join('');
  };

  const renderStep = () => {
    document.querySelectorAll('.step').forEach((step) => {
      const index = Number(step.dataset.step);
      step.classList.toggle('active', index === state.currentStep);
      step.classList.toggle('done', index < state.currentStep);
    });

    document.querySelectorAll('.step-content').forEach((content) => {
      content.classList.toggle('active', Number(content.dataset.stepContent) === state.currentStep);
    });

    updateSummary();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getAccommodation = () => API.ACCOMMODATIONS[document.getElementById('accommodationType')?.value] || API.ACCOMMODATIONS.duplo;

  const renderCompanionFields = () => {
    const target = document.getElementById('companionsFields');
    const accommodation = getAccommodation();
    if (!target) return;

    if (accommodation.mode === 'bed') {
      target.innerHTML = `
        <div class="notice">
          <strong>Alojamento coletivo</strong>
          <p class="mb-0">Neste formato a inscrição considera 1 vaga por leito. Não é necessário informar acompanhantes.</p>
        </div>
      `;
      return;
    }

    const totalCompanions = Math.max(accommodation.capacity - 1, 0);
    target.innerHTML = Array.from({ length: totalCompanions }).map((_, index) => `
      <div class="form-group">
        <label for="companion${index + 1}">Acompanhante ${index + 1}</label>
        <input class="input companion-input" id="companion${index + 1}" type="text" placeholder="Nome do acompanhante ${index + 1}">
      </div>
    `).join('');

    target.querySelectorAll('.companion-input').forEach((input) => input.addEventListener('input', updateSummary));
  };

  const validateStep = (step) => {
    Utils.clearAlert('registrationAlert');
    const form = getForm();
    const accommodation = getAccommodation();

    if (step === 1) {
      const fullName = document.getElementById('fullName').value.trim();
      const cpf = document.getElementById('cpf').value;
      const phone = document.getElementById('phone').value;
      if (!fullName || !document.getElementById('birthDate').value || !document.getElementById('gender').value) {
        Utils.showAlert('registrationAlert', 'Preencha os dados pessoais obrigatórios.', 'danger');
        return false;
      }
      if (!Utils.validateCPF(cpf)) {
        Utils.showAlert('registrationAlert', 'Informe um CPF válido.', 'danger');
        return false;
      }
      if (!Utils.validatePhone(phone)) {
        Utils.showAlert('registrationAlert', 'Informe um celular válido.', 'danger');
        return false;
      }
    }

    if (step === 2) {
      const gender = document.getElementById('gender').value;
      if (document.getElementById('accommodationType').value === 'alojamento_feminino' && gender !== 'Feminino') {
        Utils.showAlert('registrationAlert', 'Alojamento feminino aceita apenas inscritas do sexo feminino.', 'danger');
        return false;
      }
      if (document.getElementById('accommodationType').value === 'alojamento_masculino' && gender !== 'Masculino') {
        Utils.showAlert('registrationAlert', 'Alojamento masculino aceita apenas inscritos do sexo masculino.', 'danger');
        return false;
      }
      if (!accommodation) {
        Utils.showAlert('registrationAlert', 'Escolha um tipo de acomodação.', 'danger');
        return false;
      }
    }

    if (step === 4) {
      if (!document.getElementById('paymentMethod').value) {
        Utils.showAlert('registrationAlert', 'Informe a forma de pagamento.', 'danger');
        return false;
      }
    }

    if (step === 5 && !document.getElementById('termsAccepted').checked) {
      Utils.showAlert('registrationAlert', 'É necessário aceitar os termos para concluir a inscrição.', 'danger');
      return false;
    }

    return form.checkValidity();
  };

  const collectPayload = () => {
    const accommodation = getAccommodation();
    const companions = Array.from(document.querySelectorAll('.companion-input')).map((input) => input.value.trim()).filter(Boolean);
    return {
      fullName: document.getElementById('fullName').value.trim(),
      birthDate: document.getElementById('birthDate').value,
      cpf: document.getElementById('cpf').value,
      phone: document.getElementById('phone').value,
      email: document.getElementById('email').value.trim(),
      gender: document.getElementById('gender').value,
      dietaryRestrictions: document.getElementById('dietaryRestrictions').value.trim(),
      specialNeeds: document.getElementById('specialNeeds').value.trim(),
      notes: document.getElementById('notes').value.trim(),
      roomPreference: document.getElementById('roomPreference').value.trim(),
      groupName: document.getElementById('groupName').value.trim(),
      accommodationType: document.getElementById('accommodationType').value,
      companions,
      paymentMethod: document.getElementById('paymentMethod').value,
      installments: document.getElementById('installments').value,
      amountPaid: Number(document.getElementById('amountPaid').value || 0),
      proofFileName: state.proofFileName,
      termsAccepted: document.getElementById('termsAccepted').checked,
      totalValue: accommodation.price,
      vehicle: {
        vehicleName: document.getElementById('vehicleName').value.trim(),
        driver: document.getElementById('vehicleDriver').value.trim(),
        brand: document.getElementById('vehicleBrand').value.trim(),
        model: document.getElementById('vehicleModel').value.trim(),
        plate: document.getElementById('vehiclePlate').value.trim().toUpperCase(),
        color: document.getElementById('vehicleColor').value.trim(),
        year: document.getElementById('vehicleYear').value.trim()
      }
    };
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateStep(5)) return;
    const result = API.submitRegistration(collectPayload());
    if (!result.ok) {
      Utils.showAlert('registrationAlert', result.message || 'Não foi possível concluir a inscrição.', 'danger');
      return;
    }

    API.login({ profile: 'retirante', identifier: result.code });
    state.submittedCode = result.code;
    document.getElementById('successCode').textContent = result.code;
    document.getElementById('successMessage').textContent = result.message;
    document.getElementById('registrationSuccess').classList.remove('hidden');
    document.getElementById('registrationForm').classList.add('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const updateSummary = () => {
    const accommodation = getAccommodation();
    const installments = Number(document.getElementById('installments')?.value || 1);
    const amountPaid = Number(document.getElementById('amountPaid')?.value || 0);
    const companions = Array.from(document.querySelectorAll('.companion-input')).map((input) => input.value.trim()).filter(Boolean);
    const summary = document.getElementById('summaryPreview');
    if (!summary) return;

    summary.innerHTML = `
      <p><strong>Inscrito:</strong> ${document.getElementById('fullName')?.value || '—'}</p>
      <p><strong>Idade:</strong> ${Utils.calculateAge(document.getElementById('birthDate')?.value)} anos</p>
      <p><strong>Acomodação:</strong> ${accommodation.label}</p>
      <p><strong>Acompanhantes:</strong> ${companions.length ? companions.join(', ') : 'Sem acompanhantes informados'}</p>
      <p><strong>Forma de pagamento:</strong> ${document.getElementById('paymentMethod')?.value || '—'} em ${installments} parcela(s)</p>
      <p><strong>Valor total:</strong> ${Utils.currency(accommodation.price)} • <strong>Pago agora:</strong> ${Utils.currency(amountPaid)}</p>
      <p><strong>Comprovante:</strong> ${state.proofFileName || 'Não enviado'}</p>
    `;

    document.getElementById('priceHighlight').textContent = Utils.currency(accommodation.price);
    document.getElementById('installmentHighlight').textContent = Utils.currency(accommodation.price / installments);
  };

  return { init };
})();

document.addEventListener('DOMContentLoaded', InscricaoApp.init);
