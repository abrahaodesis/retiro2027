window.DashboardApp = (() => {
  const roleTabs = {
    admin: ['overview', 'occupancy', 'finance', 'meals', 'vehicles', 'users', 'reports'],
    financeiro: ['overview', 'finance', 'reports'],
    hospedagem: ['overview', 'occupancy', 'vehicles', 'reports'],
    alimentacao: ['overview', 'meals', 'reports']
  };

  let currentTab = 'overview';

  const init = () => {
    if (document.body.dataset.page !== 'dashboard') return;
    API.init();
    const session = API.getSession();
    if (!session || session.role === 'retirante') {
      window.location.href = 'login.html?perfil=admin';
      return;
    }

    const allowedTabs = roleTabs[session.role] || ['overview'];
    currentTab = allowedTabs[0];
    document.getElementById('dashboardRole').textContent = session.name;
    document.getElementById('dashboardRoleLabel').textContent = session.role;
    renderTabButtons(allowedTabs);
    bindActions(session, allowedTabs);
    renderDashboard();
  };

  const bindActions = (session, allowedTabs) => {
    document.getElementById('resetDemoData')?.addEventListener('click', () => {
      API.resetDemo();
      renderDashboard();
    });

    document.getElementById('exportJson')?.addEventListener('click', () => {
      const data = API.getDashboardData();
      Utils.downloadTextFile('retiro-espiritual-2027-dashboard.json', JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
    });

    document.getElementById('exportCsv')?.addEventListener('click', () => {
      const data = API.getDashboardData();
      const rows = data.registrations.map((registration) => {
        const participant = data.participants.find((item) => item.id === registration.participantId) || {};
        const unit = data.units.find((item) => item.id === registration.unitId) || {};
        return {
          codigo: registration.code,
          nome: participant.fullName || '',
          acomodacao: registration.accommodationLabel,
          unidade: unit.name || '',
          status_reserva: registration.reservationStatus,
          status_pagamento: registration.paymentStatus,
          total: registration.totalValue,
          pago: registration.amountPaid,
          saldo: registration.pendingBalance
        };
      });
      Utils.downloadTextFile('retiro-espiritual-2027-inscricoes.csv', Utils.objectToCSV(rows), 'text/csv;charset=utf-8');
    });

    document.getElementById('occupancyFilter')?.addEventListener('change', renderOccupancyMap);
    document.getElementById('unitSearch')?.addEventListener('input', renderOccupancyMap);

    document.addEventListener('click', (event) => {
      const tabButton = event.target.closest('[data-tab]');
      if (tabButton && allowedTabs.includes(tabButton.dataset.tab)) {
        currentTab = tabButton.dataset.tab;
        renderTabButtons(allowedTabs);
        renderSections(allowedTabs);
      }
    });
  };

  const renderTabButtons = (allowedTabs) => {
    const container = document.getElementById('tabButtons');
    const labels = {
      overview: 'Visão geral',
      occupancy: 'Mapa de ocupação',
      finance: 'Financeiro',
      meals: 'Refeições',
      vehicles: 'Veículos',
      users: 'Usuários',
      reports: 'Relatórios'
    };

    container.innerHTML = allowedTabs.map((tab) => `
      <button class="pill-btn ${currentTab === tab ? 'active' : ''}" type="button" data-tab="${tab}">${labels[tab]}</button>
    `).join('');
    renderSections(allowedTabs);
  };

  const renderSections = (allowedTabs) => {
    document.querySelectorAll('[data-section]').forEach((section) => {
      const visible = allowedTabs.includes(section.dataset.section) && section.dataset.section === currentTab;
      section.classList.toggle('hidden', !visible);
    });
  };

  const renderDashboard = () => {
    const data = API.getDashboardData();
    renderOverview(data);
    renderOccupancyMap(data);
    renderFinance(data);
    renderMeals(data);
    renderVehicles(data);
    renderUsers(data);
    renderReports(data);
  };

  const renderOverview = (data) => {
    const target = document.getElementById('overviewStats');
    target.innerHTML = `
      <div class="metric-card"><small>Total de inscritos</small><strong>${data.totals.totalRegistered}</strong></div>
      <div class="metric-card"><small>Confirmados</small><strong>${data.totals.totalConfirmed}</strong></div>
      <div class="metric-card"><small>Recebido</small><strong>${Utils.currency(data.totals.totalReceived)}</strong></div>
      <div class="metric-card"><small>Saldo pendente</small><strong>${Utils.currency(data.totals.totalPendingAmount)}</strong></div>
      <div class="metric-card"><small>Veículos cadastrados</small><strong>${data.totals.totalVehicles}</strong></div>
    `;

    const stockTable = document.getElementById('stockTableBody');
    stockTable.innerHTML = data.stock.map((item) => `
      <tr>
        <td>${item.label}</td>
        <td>${item.totalUnits}</td>
        <td>${item.availableUnits}</td>
        <td>${item.occupiedUnits}</td>
        <td>${item.mode === 'bed' ? item.usedCapacity : item.occupiedUnits}</td>
        <td>${item.waitlist}</td>
        <td>${item.occupancyRate}%</td>
      </tr>
    `).join('');

    document.getElementById('recentRegistrationsBody').innerHTML = data.recentRegistrations.map((item) => `
      <tr>
        <td>${item.code}</td>
        <td>${item.participantName}</td>
        <td>${item.accommodationLabel}</td>
        <td>${item.unitName}</td>
        <td><span class="${Utils.getStatusClass(item.reservationStatus)}">${item.reservationStatus}</span></td>
        <td>${Utils.currency(item.pendingBalance)}</td>
      </tr>
    `).join('');

    renderBarChart('ageChart', data.ageBands, 'faixas etárias');
    renderBarChart('paymentChart', data.paymentMethodSummary, 'formas de pagamento');
  };

  const renderBarChart = (targetId, dataset, label) => {
    const target = document.getElementById(targetId);
    if (!target) return;
    const values = Object.values(dataset).map((value) => Number(value) || 0);
    const max = Math.max(...values, 1);
    target.innerHTML = `
      <p class="muted">Distribuição por ${label}</p>
      <div class="bars">
        ${Object.entries(dataset).map(([key, value]) => {
          const height = Math.max((Number(value) / max) * 150, 16);
          return `<div class="bar" style="height:${height}px"><span>${Number(value).toLocaleString('pt-BR')}</span><label>${key}</label></div>`;
        }).join('')}
      </div>
    `;
  };

  const renderOccupancyMap = (existingData = null) => {
    const data = existingData || API.getDashboardData();
    const filter = document.getElementById('occupancyFilter')?.value || 'all';
    const search = (document.getElementById('unitSearch')?.value || '').toLowerCase();
    const units = data.units.filter((unit) => {
      const matchesFilter = filter === 'all' ? true : unit.type === filter;
      const matchesSearch = !search || unit.name.toLowerCase().includes(search) || unit.theme.toLowerCase().includes(search);
      return matchesFilter && matchesSearch;
    });

    const target = document.getElementById('occupancyGrid');
    target.innerHTML = units.map((unit) => {
      const occupancyClass = unit.occupants.length === 0 ? 'available' : unit.occupants.length >= unit.capacity ? 'full' : 'partial';
      return `
        <article class="unit-card ${occupancyClass}">
          <h4>${unit.name}</h4>
          <small>${unit.theme} • ${unit.type.replace(/_/g, ' ')} • código ${unit.code}</small>
          <div class="progress"><span style="width:${Math.min((unit.occupants.length / unit.capacity) * 100, 100)}%"></span></div>
          <p><strong>${unit.occupants.length}/${unit.capacity}</strong> ocupações</p>
          <p class="helper-text">${unit.occupants.length ? unit.occupants.map((item) => item.name).join(', ') : 'Unidade livre para alocação.'}</p>
        </article>
      `;
    }).join('');

    document.getElementById('occupancyLegendText').textContent = `${units.length} unidades filtradas do total de ${data.units.length}`;
  };

  const renderFinance = (data) => {
    document.getElementById('financeSummary').innerHTML = `
      <div class="metric-card"><small>Receita prevista</small><strong>${Utils.currency(data.totals.totalRevenue)}</strong></div>
      <div class="metric-card"><small>Total arrecadado</small><strong>${Utils.currency(data.totals.totalReceived)}</strong></div>
      <div class="metric-card"><small>Inadimplentes</small><strong>${data.reports.inadimplentes}</strong></div>
      <div class="metric-card"><small>Inscrições quitadas</small><strong>${data.reports.quitadas}</strong></div>
    `;

    document.getElementById('financeTableBody').innerHTML = data.registrations.map((registration) => {
      const participant = data.participants.find((item) => item.id === registration.participantId) || {};
      return `
        <tr>
          <td>${registration.code}</td>
          <td>${participant.fullName || '—'}</td>
          <td>${registration.paymentMethod}</td>
          <td>${registration.installments}x de ${Utils.currency(registration.installmentAmount)}</td>
          <td>${Utils.currency(registration.amountPaid)}</td>
          <td>${Utils.currency(registration.pendingBalance)}</td>
          <td><span class="${Utils.getStatusClass(registration.paymentStatus)}">${registration.paymentStatus}</span></td>
        </tr>
      `;
    }).join('');
  };

  const renderMeals = (data) => {
    const restrictionsList = data.participants.filter((item) => item.dietaryRestrictions || item.specialNeeds);
    document.getElementById('mealSummaryBody').innerHTML = data.mealSummary.map((item) => `
      <tr>
        <td>${Utils.formatDate(item.date)}</td>
        <td>${item.cafe}</td>
        <td>${item.almoco}</td>
        <td>${item.jantar}</td>
        <td>${item.lanches}</td>
        <td>${item.especiais}</td>
      </tr>
    `).join('');

    document.getElementById('restrictionsList').innerHTML = restrictionsList.length
      ? restrictionsList.map((item) => `<li><strong>${item.fullName}</strong><br><span class="muted">${item.dietaryRestrictions || 'Sem restrição alimentar'} • ${item.specialNeeds || 'Sem necessidade especial'}</span></li>`).join('')
      : '<li>Nenhuma restrição registrada.</li>';
  };

  const renderVehicles = (data) => {
    document.getElementById('vehiclesBody').innerHTML = data.vehicles.length
      ? data.vehicles.map((vehicle) => `
        <tr>
          <td>${vehicle.vehicleName}</td>
          <td>${vehicle.driver}</td>
          <td>${vehicle.brand}</td>
          <td>${vehicle.model}</td>
          <td>${vehicle.plate}</td>
          <td>${vehicle.color}</td>
          <td>${vehicle.year}</td>
        </tr>
      `).join('')
      : '<tr><td colspan="7">Nenhum veículo cadastrado.</td></tr>';
  };

  const renderUsers = (data) => {
    document.getElementById('usersBody').innerHTML = data.users.map((user) => `
      <tr>
        <td>${user.name}</td>
        <td>${user.role}</td>
        <td>${user.username}</td>
        <td>${user.password}</td>
      </tr>
    `).join('');

    document.getElementById('auditBody').innerHTML = data.auditLogs.map((entry) => `
      <tr>
        <td>${Utils.formatDateTime(entry.createdAt)}</td>
        <td>${entry.actor}</td>
        <td>${entry.action}</td>
        <td>${entry.details}</td>
      </tr>
    `).join('');
  };

  const renderReports = (data) => {
    document.getElementById('reportCards').innerHTML = `
      <div class="card"><h4>Taxa de ocupação</h4><p>${data.stock.map((item) => `${item.label}: ${item.occupancyRate}%`).join('<br>')}</p></div>
      <div class="card"><h4>Resumo por sexo</h4><p>Feminino: ${data.sexCount.Feminino || 0}<br>Masculino: ${data.sexCount.Masculino || 0}</p></div>
      <div class="card"><h4>Observações operacionais</h4><p>PCD: ${data.reports.pcd}<br>Restrições alimentares: ${data.reports.restricoes}<br>Fila de espera: ${data.totals.waitlist}</p></div>
    `;
  };

  return { init };
})();

document.addEventListener('DOMContentLoaded', DashboardApp.init);
