window.Utils = (() => {
  const DATE_LOCALE = 'pt-BR';

  const sanitizeDigits = (value = '') => String(value).replace(/\D/g, '');

  const currency = (value = 0) => Number(value || 0).toLocaleString(DATE_LOCALE, {
    style: 'currency',
    currency: 'BRL'
  });

  const formatDate = (value) => {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleDateString(DATE_LOCALE);
  };

  const formatDateTime = (value) => {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return `${date.toLocaleDateString(DATE_LOCALE)} ${date.toLocaleTimeString(DATE_LOCALE, { hour: '2-digit', minute: '2-digit' })}`;
  };

  const calculateAge = (birthDate) => {
    if (!birthDate) return 0;
    const today = new Date();
    const birth = new Date(birthDate);
    if (Number.isNaN(birth.getTime())) return 0;
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age -= 1;
    }
    return age;
  };

  const cpfMask = (value = '') => {
    const digits = sanitizeDigits(value).slice(0, 11);
    return digits
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  };

  const phoneMask = (value = '') => {
    const digits = sanitizeDigits(value).slice(0, 11);
    if (digits.length <= 10) {
      return digits.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{4})(\d{1,4})$/, '$1-$2');
    }
    return digits.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d{1,4})$/, '$1-$2');
  };

  const validateCPF = (cpf) => {
    const digits = sanitizeDigits(cpf);
    if (!digits || digits.length !== 11 || /^(\d)\1+$/.test(digits)) return false;

    let sum = 0;
    for (let i = 0; i < 9; i += 1) sum += Number(digits.charAt(i)) * (10 - i);
    let remainder = (sum * 10) % 11;
    if (remainder === 10) remainder = 0;
    if (remainder !== Number(digits.charAt(9))) return false;

    sum = 0;
    for (let i = 0; i < 10; i += 1) sum += Number(digits.charAt(i)) * (11 - i);
    remainder = (sum * 10) % 11;
    if (remainder === 10) remainder = 0;
    return remainder === Number(digits.charAt(10));
  };

  const validatePhone = (phone) => sanitizeDigits(phone).length >= 10;

  const slugify = (text = '') => text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');

  const generateCode = (prefix = 'RET2027', serial = Date.now()) => `${prefix}-${String(serial).padStart(4, '0')}`;

  const load = (key, fallback = null) => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      console.error('Erro ao carregar storage', error);
      return fallback;
    }
  };

  const save = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Erro ao salvar storage', error);
      return false;
    }
  };

  const clone = (value) => JSON.parse(JSON.stringify(value));

  const getStatusClass = (status = '') => {
    const normalized = slugify(status);
    if (!normalized) return 'status';
    return `status status-${normalized}`;
  };

  const showAlert = (targetId, message, type = 'success') => {
    const target = document.getElementById(targetId);
    if (!target) return;
    target.className = `alert show alert-${type}`;
    target.textContent = message;
  };

  const clearAlert = (targetId) => {
    const target = document.getElementById(targetId);
    if (!target) return;
    target.className = 'alert';
    target.textContent = '';
  };

  const downloadTextFile = (filename, content, type = 'text/plain;charset=utf-8') => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const objectToCSV = (rows = []) => {
    if (!rows.length) return '';
    const headers = Object.keys(rows[0]);
    const escape = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    return [headers.join(','), ...rows.map((row) => headers.map((header) => escape(row[header])).join(','))].join('\n');
  };

  const setText = (selector, value) => {
    const element = document.querySelector(selector);
    if (element) element.textContent = value;
  };

  const groupBy = (items, key) => items.reduce((acc, item) => {
    const groupKey = typeof key === 'function' ? key(item) : item[key];
    acc[groupKey] = acc[groupKey] || [];
    acc[groupKey].push(item);
    return acc;
  }, {});

  const sumBy = (items, fn) => items.reduce((total, item) => total + Number(fn(item) || 0), 0);

  return {
    sanitizeDigits,
    currency,
    formatDate,
    formatDateTime,
    calculateAge,
    cpfMask,
    phoneMask,
    validateCPF,
    validatePhone,
    slugify,
    generateCode,
    load,
    save,
    clone,
    getStatusClass,
    showAlert,
    clearAlert,
    downloadTextFile,
    objectToCSV,
    setText,
    groupBy,
    sumBy
  };
})();
