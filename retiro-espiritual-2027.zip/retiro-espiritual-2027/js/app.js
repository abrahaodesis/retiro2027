window.App = (() => {
  const page = document.body.dataset.page;

  const roleLabels = {
    admin: 'Administrador Geral',
    financeiro: 'Equipe Financeira',
    hospedagem: 'Equipe Hospedagem',
    alimentacao: 'Equipe Alimentação',
    retirante: 'Retirante'
  };

  const init = () => {
    API.init();
    bindGlobalEvents();
    renderSessionBanner();
    Utils.setText('[data-current-year]', new Date().getFullYear());

    if (page === 'index') initLanding();
    if (page === 'login') initLogin();
    if (page === 'perfil') initProfile();
  };

  const bindGlobalEvents = () => {
    document.querySelectorAll('[data-logout]').forEach((button) => {
      button.addEventListener('click', () => {
        API.logout();
        window.location.href = 'login.html';
      });
    });
  };

  const renderSessionBanner = () => {
    const session = API.getSession();
    const target = document.querySelector('[data-session-info]');
    if (!target) return;

    if (!session) {
      target.innerHTML = '<span class="muted">Nenhuma sessão ativa</span>';
      return;
    }

    target.innerHTML = `
      <div class="mini-card">
        <strong>${session.name}</strong>
        <div class="helper-text">${roleLabels[session.role] || 'Sessão ativa'}</div>
      </div>
    `;
  };

  const initLanding = () => {
    renderAccommodationCards();
    initCountdown();
    const dashboard = API.getDashboardData();
    Utils.setText('#landingTotalInscritos', dashboard.totals.totalRegistered);
    Utils.setText('#landingReceita', Utils.currency(dashboard.totals.totalRevenue));
    Utils.setText('#landingRecebido', Utils.currency(dashboard.totals.totalReceived));
    Utils.setText('#landingUnidades', dashboard.units.length);
  };

  const renderAccommodationCards = () => {
    const target = document.getElementById('accommodationCards');
    if (!target) return;

    const labels = {
      duplo: 'Perfeito para casais ou dupla de afinidade.',
      triplo: 'Ideal para famílias pequenas e grupos de amizade.',
      quadruplo: 'Boa relação custo-benefício para grupos de 4.',
      quintuplo: 'Formato econômico para grupos maiores.',
      suite_master: 'Unidade premium com ocupação configurável.',
      alojamento_feminino: 'Controle por alas/unidades femininas com vagas por leito.',
      alojamento_masculino: 'Controle por alas/unidades masculinas com vagas por leito.'
    };

    const cards = API.getAccommodationStock().map((item) => `
      <article class="card accommodation-card">
        <div class="info-chip">${item.totalUnits} unidades físicas</div>
        <h3>${item.label}</h3>
        <p>${labels[item.key] || ''}</p>
        <div class="price">${Utils.currency(item.price)}</div>
        <div class="tag">${item.availableUnits} unidades com disponibilidade</div>
        <div class="tag">Ocupação ${item.occupancyRate}%</div>
        <div class="tag">Fila de espera ${item.waitlist}</div>
      </article>
    `).join('');

    target.innerHTML = cards;
  };

  const initCountdown = () => {
    const target = document.getElementById('countdown');
    if (!target) return;

    const openingDate = new Date('2026-04-18T00:00:00-03:00').getTime();
    const statusTarget = document.getElementById('openingStatus');

    const update = () => {
      const distance = openingDate - Date.now();
      if (distance <= 0) {
        target.innerHTML = [
          ['00', 'Dias'],
          ['00', 'Horas'],
          ['00', 'Minutos'],
          ['00', 'Segundos']
        ].map(([value, label]) => `<div class="countdown-item"><strong>${value}</strong><span>${label}</span></div>`).join('');
        if (statusTarget) statusTarget.textContent = 'As inscrições já foram iniciadas. Utilize a Área do Participante ou a Área Administrativa para continuar.';
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((distance / (1000 * 60)) % 60);
      const seconds = Math.floor((distance / 1000) % 60);
      target.innerHTML = [
        [String(days).padStart(2, '0'), 'Dias'],
        [String(hours).padStart(2, '0'), 'Horas'],
        [String(minutes).padStart(2, '0'), 'Minutos'],
        [String(seconds).padStart(2, '0'), 'Segundos']
      ].map(([value, label]) => `<div class="countdown-item"><strong>${value}</strong><span>${label}</span></div>`).join('');
      if (statusTarget) statusTarget.textContent = 'Contagem regressiva para a abertura oficial das inscrições em 18/04/2026.';
    };

    update();
    setInterval(update, 1000);
  };

  const initLogin = () => {
    const profileSelect = document.getElementById('profileSelect');
    const staffFields = document.getElementById('staffFields');
    const participantFields = document.getElementById('participantFields');
    const tips = document.getElementById('loginTip');
    const form = document.getElementById('loginForm');
    const alertId = 'loginAlert';

    if (!form || !profileSelect) return;

    const staffPresets = {
      admin: { username: 'admin', password: 'retiro2027', tip: 'Administrador Geral: admin / retiro2027' },
      financeiro: { username: 'financeiro', password: 'financeiro2027', tip: 'Equipe Financeira: financeiro / financeiro2027' },
      hospedagem: { username: 'hospedagem', password: 'hospedagem2027', tip: 'Equipe de Hospedagem: hospedagem / hospedagem2027' },
      alimentacao: { username: 'alimentacao', password: 'alimentacao2027', tip: 'Equipe de Alimentação: alimentacao / alimentacao2027' },
      retirante: { username: '', password: '', tip: 'Retirante: entre com CPF ou código de inscrição. Exemplo demo: 529.982.247-25 ou RET2027-1007.' }
    };

    const updateProfileMode = () => {
      const profile = profileSelect.value;
      const preset = staffPresets[profile];
      staffFields.classList.toggle('hidden', profile === 'retirante');
      participantFields.classList.toggle('hidden', profile !== 'retirante');
      document.getElementById('username').value = preset.username;
      document.getElementById('password').value = preset.password;
      tips.textContent = preset.tip;
      Utils.clearAlert(alertId);
    };

    updateProfileMode();
    profileSelect.addEventListener('change', updateProfileMode);

    document.querySelectorAll('[data-profile-card]').forEach((card) => {
      card.addEventListener('click', () => {
        profileSelect.value = card.dataset.profileCard;
        updateProfileMode();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });

    const queryProfile = new URLSearchParams(window.location.search).get('perfil');
    if (queryProfile && staffPresets[queryProfile]) {
      profileSelect.value = queryProfile;
      updateProfileMode();
    }

    const createdCode = new URLSearchParams(window.location.search).get('codigo');
    if (createdCode) {
      Utils.showAlert(alertId, `Inscrição registrada com sucesso. Seu código é ${createdCode}.`, 'success');
      profileSelect.value = 'retirante';
      updateProfileMode();
      document.getElementById('identifier').value = createdCode;
    }

    const participantDemo = API.getDashboardData().recentRegistrations[0];
    const demoBtn = document.getElementById('fillParticipantDemo');
    if (demoBtn && participantDemo) {
      demoBtn.addEventListener('click', () => {
        profileSelect.value = 'retirante';
        updateProfileMode();
        document.getElementById('identifier').value = participantDemo.code;
      });
    }

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      Utils.clearAlert(alertId);
      const profile = profileSelect.value;
      const payload = { profile };

      if (profile === 'retirante') {
        payload.identifier = document.getElementById('identifier').value;
      } else {
        payload.username = document.getElementById('username').value.trim();
        payload.password = document.getElementById('password').value.trim();
      }

      const result = API.login(payload);
      if (!result.ok) {
        Utils.showAlert(alertId, result.message, 'danger');
        return;
      }

      Utils.showAlert(alertId, 'Autenticação realizada. Redirecionando...', 'success');
      setTimeout(() => {
        window.location.href = result.redirect;
      }, 600);
    });
  };

  const initProfile = () => {
    const session = API.getSession();
    if (!session || session.role !== 'retirante') {
      window.location.href = 'login.html?perfil=retirante';
      return;
    }

    const profile = API.getParticipantProfile(session.participantId);
    if (!profile) {
      window.location.href = 'login.html?perfil=retirante';
      return;
    }

    renderProfile(profile);
    bindProfileActions(profile);
  };

  const renderProfile = (data) => {
    const { participant, registration, payments, unit, vehicle } = data;
    Utils.setText('#profileName', participant.fullName);
    Utils.setText('#profileCode', participant.code);
    Utils.setText('#profileAccommodation', registration.accommodationLabel);
    Utils.setText('#profileStatus', registration.reservationStatus);
    Utils.setText('#paymentStatusText', registration.paymentStatus);
    Utils.setText('#participantAge', `${Utils.calculateAge(participant.birthDate)} anos`);
    Utils.setText('#participantCpf', Utils.cpfMask(participant.cpf));
    Utils.setText('#participantPhone', Utils.phoneMask(participant.phone));
    Utils.setText('#participantRestrictions', participant.dietaryRestrictions || 'Nenhuma restrição informada');
    Utils.setText('#participantNeeds', participant.specialNeeds || 'Nenhuma necessidade especial informada');
    Utils.setText('#participantNotes', participant.notes || 'Sem observações adicionais');
    Utils.setText('#participantUnit', unit ? `${unit.name} • ${registration.accommodationLabel}` : 'Aguardando alocação');
    Utils.setText('#participantPaymentTotal', Utils.currency(registration.totalValue));
    Utils.setText('#participantPaymentPaid', Utils.currency(registration.amountPaid));
    Utils.setText('#participantPaymentPending', Utils.currency(registration.pendingBalance));
    Utils.setText('#participantVehicle', vehicle ? `${vehicle.brand} ${vehicle.model} • ${vehicle.plate}` : 'Nenhum veículo cadastrado');

    const progress = registration.totalValue ? Math.min((registration.amountPaid / registration.totalValue) * 100, 100) : 0;
    document.getElementById('paymentProgress').style.width = `${progress}%`;
    document.getElementById('statusBadge').className = Utils.getStatusClass(registration.paymentStatus);
    document.getElementById('statusBadge').textContent = registration.paymentStatus;
    document.getElementById('reservationBadge').className = Utils.getStatusClass(registration.reservationStatus);
    document.getElementById('reservationBadge').textContent = registration.reservationStatus;

    const paymentsTable = document.getElementById('paymentsTableBody');
    paymentsTable.innerHTML = payments.length
      ? payments.map((payment) => `
        <tr>
          <td>${payment.id}</td>
          <td>${Utils.formatDateTime(payment.createdAt)}</td>
          <td>${payment.method}</td>
          <td>${Utils.currency(payment.amount)}</td>
          <td>${payment.status}</td>
        </tr>
      `).join('')
      : '<tr><td colspan="5">Nenhum pagamento registrado até o momento.</td></tr>';

    document.getElementById('receiptContent').innerHTML = `
      <div class="receipt-grid">
        <div>
          <small class="muted">Retirante</small>
          <p><strong>${participant.fullName}</strong><br>${participant.code}<br>${Utils.cpfMask(participant.cpf)}</p>
        </div>
        <div>
          <small class="muted">Hospedagem</small>
          <p><strong>${registration.accommodationLabel}</strong><br>${unit ? unit.name : 'Aguardando unidade'}<br>Status ${registration.reservationStatus}</p>
        </div>
        <div>
          <small class="muted">Financeiro</small>
          <p>Total ${Utils.currency(registration.totalValue)}<br>Pago ${Utils.currency(registration.amountPaid)}<br>Saldo ${Utils.currency(registration.pendingBalance)}</p>
        </div>
        <div>
          <small class="muted">Evento</small>
          <p>05/02/2027 a 10/02/2027<br>Hotel Fazenda Amoras<br>Santo Antônio de Jesus - BA</p>
        </div>
      </div>
    `;
  };

  const bindProfileActions = (data) => {
    document.getElementById('printReceipt')?.addEventListener('click', () => window.print());
    document.getElementById('passwordForm')?.addEventListener('submit', (event) => {
      event.preventDefault();
      const newPassword = document.getElementById('newPassword').value.trim();
      if (newPassword.length < 4) {
        Utils.showAlert('profileAlert', 'Defina uma senha com pelo menos 4 caracteres.', 'danger');
        return;
      }
      const result = API.updateParticipantPassword(data.participant.id, newPassword);
      Utils.showAlert('profileAlert', result.message, result.ok ? 'success' : 'danger');
      if (result.ok) document.getElementById('passwordForm').reset();
    });
  };

  return { init };
})();

document.addEventListener('DOMContentLoaded', App.init);
