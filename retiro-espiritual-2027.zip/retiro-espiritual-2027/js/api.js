window.API = (() => {
  const DB_KEY = 'retiro2027-db';
  const SESSION_KEY = 'retiro2027-session';

  const ACCOMMODATIONS = {
    duplo: { label: 'Apartamento Duplo', units: 18, capacity: 2, price: 4000, mode: 'unit' },
    triplo: { label: 'Apartamento Triplo', units: 25, capacity: 3, price: 5400, mode: 'unit' },
    quadruplo: { label: 'Apartamento Quádruplo', units: 18, capacity: 4, price: 6600, mode: 'unit' },
    quintuplo: { label: 'Apartamento Quíntuplo', units: 3, capacity: 5, price: 7500, mode: 'unit' },
    suite_master: { label: 'Suíte Master', units: 2, capacity: 2, price: 6500, mode: 'unit' },
    alojamento_feminino: { label: 'Alojamento Feminino', units: 8, capacity: 30, price: 1300, mode: 'bed', gender: 'Feminino' },
    alojamento_masculino: { label: 'Alojamento Masculino', units: 8, capacity: 30, price: 1300, mode: 'bed', gender: 'Masculino' }
  };

  const USERS = [
    { id: 'u-admin', username: 'admin', password: 'retiro2027', role: 'admin', name: 'Administrador Geral' },
    { id: 'u-financeiro', username: 'financeiro', password: 'financeiro2027', role: 'financeiro', name: 'Equipe Financeira' },
    { id: 'u-hospedagem', username: 'hospedagem', password: 'hospedagem2027', role: 'hospedagem', name: 'Equipe de Hospedagem' },
    { id: 'u-alimentacao', username: 'alimentacao', password: 'alimentacao2027', role: 'alimentacao', name: 'Equipe de Alimentação' }
  ];

  const THEME_NAMES = {
    Flores: ['Acácia', 'Azaleia', 'Begônia', 'Bromélia', 'Camélia', 'Dália', 'Gardênia', 'Girassol', 'Hortênsia', 'Íris', 'Jasmim', 'Lavanda', 'Magnólia', 'Margarida', 'Orquídea', 'Peônia', 'Petúnia', 'Primavera', 'Rosa', 'Tulipa', 'Violeta'],
    Frutas: ['Amora', 'Acerola', 'Banana', 'Cacau', 'Cajá', 'Caju', 'Cupuaçu', 'Figo', 'Framboesa', 'Goiaba', 'Graviola', 'Jabuticaba', 'Kiwi', 'Laranja', 'Limão', 'Maçã', 'Manga', 'Melancia', 'Pêra', 'Pitanga', 'Uva'],
    Pássaros: ['Andorinha', 'Arara', 'Bem-te-vi', 'Beija-flor', 'Canário', 'Cardeal', 'Coleiro', 'Coruja', 'Curió', 'Flamingo', 'Garça', 'João-de-Barro', 'Papagaio', 'Pardal', 'Patativa', 'Pavão', 'Periquito', 'Rolinha', 'Sabiá', 'Tucano'],
    Árvores: ['Aroeira', 'Baobá', 'Cajueiro', 'Carvalho', 'Cedro', 'Eucalipto', 'Figueira', 'Goiabeira', 'Ipê', 'Jaqueira', 'Jequitibá', 'Mangueira', 'Oliveira', 'Paineira', 'Pau-Brasil', 'Pinheiro', 'Seringueira', 'Umbuzeiro', 'Vitória-Régia', 'Ypê-Amarelo']
  };

  const FEMALE_DORM_CAPACITIES = [4, 4, 4, 4, 4, 4, 3, 3];
  const MALE_DORM_CAPACITIES = [4, 4, 4, 4, 4, 4, 3, 3];

  const baseDates = {
    eventStart: '2027-02-05',
    eventEnd: '2027-02-10',
    opening: '2026-04-18'
  };

  const clone = (value) => JSON.parse(JSON.stringify(value));

  const saveDb = (db) => Utils.save(DB_KEY, db);
  const loadDb = () => Utils.load(DB_KEY, null);

  const saveSession = (session) => Utils.save(SESSION_KEY, session);
  const loadSession = () => Utils.load(SESSION_KEY, null);

  const generateUnits = () => {
    const allNames = [];
    Object.entries(THEME_NAMES).forEach(([theme, names]) => {
      names.forEach((name) => allNames.push({ theme, name }));
    });

    const units = [];
    let pointer = 0;

    const nextName = () => {
      const current = allNames[pointer];
      pointer += 1;
      return current;
    };

    const makeUnit = (type, capacity, indexLabel) => {
      const current = nextName();
      return {
        id: `unit-${indexLabel}`,
        code: String(indexLabel).padStart(2, '0'),
        name: current.name,
        theme: current.theme,
        type,
        capacity,
        occupants: [],
        notes: '',
        housekeepingStatus: 'pronto'
      };
    };

    let label = 1;
    Array.from({ length: 18 }).forEach(() => units.push(makeUnit('duplo', 2, label++)));
    Array.from({ length: 25 }).forEach(() => units.push(makeUnit('triplo', 3, label++)));
    Array.from({ length: 18 }).forEach(() => units.push(makeUnit('quadruplo', 4, label++)));
    Array.from({ length: 3 }).forEach(() => units.push(makeUnit('quintuplo', 5, label++)));
    Array.from({ length: 2 }).forEach(() => units.push(makeUnit('suite_master', 2, label++)));
    FEMALE_DORM_CAPACITIES.forEach((capacity) => units.push(makeUnit('alojamento_feminino', capacity, label++)));
    MALE_DORM_CAPACITIES.forEach((capacity) => units.push(makeUnit('alojamento_masculino', capacity, label++)));

    return units;
  };

  const nowIso = () => new Date().toISOString();

  const addAudit = (db, actor, action, details) => {
    db.auditLogs.unshift({
      id: `audit-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`,
      actor,
      action,
      details,
      createdAt: nowIso()
    });
    db.auditLogs = db.auditLogs.slice(0, 80);
  };

  const createBaseDb = () => ({
    meta: {
      name: 'Retiro Espiritual 2027',
      church: 'Igreja Batista Lírio Armação',
      ...baseDates,
      generatedAt: nowIso()
    },
    users: clone(USERS),
    participants: [],
    registrations: [],
    payments: [],
    units: generateUnits(),
    vehicles: [],
    auditLogs: [],
    counters: { registration: 1000, payment: 5000, participant: 300 }
  });

  const nextCounter = (db, name) => {
    db.counters[name] += 1;
    return db.counters[name];
  };

  const getAvailableUnit = (db, registration) => {
    if (registration.accommodationType === 'alojamento_feminino' || registration.accommodationType === 'alojamento_masculino') {
      return db.units.find((unit) => unit.type === registration.accommodationType && unit.occupants.length < unit.capacity) || null;
    }
    return db.units.find((unit) => unit.type === registration.accommodationType && unit.occupants.length === 0) || null;
  };

  const totalPaidForRegistration = (db, registrationId) => db.payments
    .filter((payment) => payment.registrationId === registrationId)
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);

  const normalizeStatus = (registration, totalPaid) => {
    const balance = Number(registration.totalValue) - Number(totalPaid || 0);
    registration.amountPaid = totalPaid;
    registration.pendingBalance = Math.max(balance, 0);

    if (registration.reservationStatus === 'lista de espera' || registration.reservationStatus === 'cancelada') {
      registration.paymentStatus = registration.reservationStatus === 'cancelada' ? 'cancelada' : 'pendente';
      return registration;
    }

    if (balance <= 0) {
      registration.reservationStatus = 'confirmada';
      registration.paymentStatus = 'quitada';
      return registration;
    }

    if (totalPaid > 0) {
      registration.reservationStatus = 'pendente de pagamento';
      registration.paymentStatus = 'pagamento parcial';
      return registration;
    }

    registration.reservationStatus = 'pré-reserva';
    registration.paymentStatus = 'pendente';
    return registration;
  };

  const attachToUnit = (db, registration, participant) => {
    const unit = getAvailableUnit(db, registration);
    if (!unit) {
      registration.reservationStatus = 'lista de espera';
      registration.unitId = null;
      return null;
    }

    registration.unitId = unit.id;
    const companions = (registration.companions || []).filter((name) => name && name.trim());
    const occupants = [{ name: participant.fullName, code: registration.code, main: true }, ...companions.map((name, index) => ({ name, code: `${registration.code}-A${index + 1}`, main: false }))];

    if (registration.accommodationType === 'alojamento_feminino' || registration.accommodationType === 'alojamento_masculino') {
      unit.occupants.push({ name: participant.fullName, code: registration.code, main: true });
    } else {
      unit.occupants = occupants;
    }

    return unit;
  };

  const createPayment = (db, registration, method, amount, note = 'Pagamento registrado') => {
    if (!amount || Number(amount) <= 0) return null;
    const payment = {
      id: `PAY-${nextCounter(db, 'payment')}`,
      registrationId: registration.id,
      amount: Number(amount),
      method,
      status: 'compensado',
      note,
      createdAt: nowIso()
    };
    db.payments.push(payment);
    return payment;
  };

  const createRegistrationInternal = (db, payload, actor = 'Sistema', seeded = false) => {
    const participantId = `PART-${nextCounter(db, 'participant')}`;
    const registrationId = `REG-${nextCounter(db, 'registration')}`;
    const code = Utils.generateCode('RET2027', db.counters.registration);
    const accommodation = ACCOMMODATIONS[payload.accommodationType];
    const companions = (payload.companions || []).filter(Boolean);
    const totalValue = Number(payload.totalValue ?? accommodation.price);

    const participant = {
      id: participantId,
      fullName: payload.fullName,
      birthDate: payload.birthDate,
      age: Utils.calculateAge(payload.birthDate),
      cpf: Utils.sanitizeDigits(payload.cpf),
      phone: Utils.sanitizeDigits(payload.phone),
      email: payload.email || '',
      gender: payload.gender,
      dietaryRestrictions: payload.dietaryRestrictions || '',
      specialNeeds: payload.specialNeeds || '',
      notes: payload.notes || '',
      roomPreference: payload.roomPreference || '',
      groupName: payload.groupName || '',
      code,
      appPassword: payload.appPassword || Utils.sanitizeDigits(payload.cpf).slice(-4),
      createdAt: nowIso()
    };

    const registration = {
      id: registrationId,
      participantId,
      code,
      accommodationType: payload.accommodationType,
      accommodationLabel: accommodation.label,
      groupSize: accommodation.mode === 'unit' ? Math.max(1, Math.min(accommodation.capacity, companions.length + 1)) : 1,
      companions,
      paymentMethod: payload.paymentMethod || 'PIX',
      installments: Number(payload.installments || 1),
      installmentAmount: Number((totalValue / Number(payload.installments || 1)).toFixed(2)),
      totalValue,
      amountPaid: 0,
      pendingBalance: totalValue,
      reservationStatus: 'pré-reserva',
      paymentStatus: 'pendente',
      registrationStatus: 'em análise',
      receiptUrl: '#',
      proofFileName: payload.proofFileName || '',
      vehicleId: null,
      unitId: null,
      termsAccepted: Boolean(payload.termsAccepted),
      checkInStatus: payload.checkInStatus || 'pendente',
      createdAt: nowIso(),
      expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString()
    };

    db.participants.push(participant);
    db.registrations.push(registration);
    const unit = attachToUnit(db, registration, participant);

    if (payload.vehicle && payload.vehicle.plate) {
      const vehicle = {
        id: `VEH-${participantId}`,
        participantId,
        registrationId,
        vehicleName: payload.vehicle.vehicleName || 'Veículo Particular',
        driver: payload.vehicle.driver || participant.fullName,
        brand: payload.vehicle.brand || '',
        model: payload.vehicle.model || '',
        plate: payload.vehicle.plate || '',
        color: payload.vehicle.color || '',
        year: payload.vehicle.year || ''
      };
      db.vehicles.push(vehicle);
      registration.vehicleId = vehicle.id;
    }

    const payment = createPayment(db, registration, registration.paymentMethod, payload.amountPaid || 0, seeded ? 'Pagamento demo' : 'Pagamento inicial');
    normalizeStatus(registration, totalPaidForRegistration(db, registration.id));
    registration.registrationStatus = registration.reservationStatus === 'lista de espera' ? 'lista de espera' : (registration.paymentStatus === 'quitada' ? 'confirmada' : 'pendente');

    addAudit(db, actor, seeded ? 'Carga inicial de inscrição' : 'Nova inscrição criada', `${participant.fullName} • ${registration.accommodationLabel}${unit ? ` • unidade ${unit.name}` : ' • lista de espera'}`);
    if (payment) addAudit(db, actor, 'Pagamento registrado', `${registration.code} • ${Utils.currency(payment.amount)} via ${payment.method}`);

    return { participant, registration, unit };
  };

  const seedDemoData = (db) => {
    const demoEntries = [
      {
        fullName: 'Aline Santos', birthDate: '1990-06-14', cpf: '21345678909', phone: '71998887766', email: 'aline@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: 'Sem lactose', specialNeeds: '', notes: 'Deseja ficar perto de Joana.', roomPreference: 'Joana Melo', groupName: 'Família Santos',
        accommodationType: 'duplo', companions: ['Joana Melo'], paymentMethod: 'PIX', amountPaid: 4000, installments: 1,
        vehicle: { vehicleName: 'SUV', driver: 'Aline Santos', brand: 'Jeep', model: 'Compass', plate: 'PLA2A27', color: 'Branco', year: '2023' }, termsAccepted: true, checkInStatus: 'pendente'
      },
      {
        fullName: 'Carlos Almeida', birthDate: '1985-03-22', cpf: '39053344705', phone: '71993334455', email: 'carlos@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: '', specialNeeds: '', notes: 'Chega em ônibus fretado.', roomPreference: '', groupName: 'Casal Almeida',
        accommodationType: 'suite_master', companions: ['Marina Almeida'], paymentMethod: 'Cartão', amountPaid: 3250, installments: 2, termsAccepted: true
      },
      {
        fullName: 'Marina Almeida', birthDate: '1988-11-11', cpf: '98765432100', phone: '71991112233', email: 'marina@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: 'Vegetariana', specialNeeds: '', notes: 'Vinculada à reserva do marido.', roomPreference: 'Carlos Almeida', groupName: 'Casal Almeida',
        accommodationType: 'alojamento_feminino', companions: [], paymentMethod: 'PIX', amountPaid: 650, installments: 2, termsAccepted: true
      },
      {
        fullName: 'Rafael Oliveira', birthDate: '1997-09-02', cpf: '12345678909', phone: '71990011223', email: 'rafael@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: '', specialNeeds: 'PCD - mobilidade reduzida', notes: 'Precisa de unidade térrea.', roomPreference: '', groupName: 'Jovens',
        accommodationType: 'triplo', companions: ['Lucas Dias', 'Thiago Reis'], paymentMethod: 'Transferência', amountPaid: 2700, installments: 2, termsAccepted: true
      },
      {
        fullName: 'Débora Costa', birthDate: '1978-01-29', cpf: '93541134780', phone: '71995556677', email: 'debora@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: 'Sem glúten', specialNeeds: '', notes: 'Alergia a castanhas.', roomPreference: '', groupName: 'Ministério Mulheres',
        accommodationType: 'quadruplo', companions: ['Rita Matos', 'Paula Souza', 'Cláudia Lima'], paymentMethod: 'Boleto', amountPaid: 3300, installments: 2, termsAccepted: true
      },
      {
        fullName: 'Pedro Silva', birthDate: '2001-05-17', cpf: '11144477735', phone: '71994445566', email: 'pedro@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: '', specialNeeds: '', notes: 'Conduz van do grupo.', roomPreference: '', groupName: 'Jovens',
        accommodationType: 'alojamento_masculino', companions: [], paymentMethod: 'Dinheiro', amountPaid: 1300, installments: 1,
        vehicle: { vehicleName: 'Van', driver: 'Pedro Silva', brand: 'Mercedes', model: 'Sprinter', plate: 'RET2B27', color: 'Prata', year: '2021' }, termsAccepted: true, checkInStatus: 'pendente'
      },
      {
        fullName: 'Luciana Prado', birthDate: '1993-07-30', cpf: '52998224725', phone: '71996667788', email: 'luciana@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: 'Sem açúcar', specialNeeds: '', notes: '', roomPreference: '', groupName: 'Equipe Louvor',
        accommodationType: 'duplo', companions: ['Eliane Prado'], paymentMethod: 'PIX', amountPaid: 2000, installments: 2, termsAccepted: true
      },
      {
        fullName: 'Gustavo Nunes', birthDate: '1971-12-05', cpf: '86855165060', phone: '71997778899', email: 'gustavo@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: '', specialNeeds: '', notes: 'Prefere quarto silencioso.', roomPreference: '', groupName: 'Conselho',
        accommodationType: 'quintuplo', companions: ['Adriano Paz', 'Mateus Azevedo', 'Samuel Freitas', 'Elias Rocha'], paymentMethod: 'PIX', amountPaid: 7500, installments: 1, termsAccepted: true, checkInStatus: 'pendente'
      },
      {
        fullName: 'Bianca Ferreira', birthDate: '2005-10-09', cpf: '70369269090', phone: '71990000111', email: 'bianca@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: 'Vegana', specialNeeds: '', notes: 'Solicitou dispensa de jantar no dia 08/02.', roomPreference: '', groupName: 'Jovens',
        accommodationType: 'alojamento_feminino', companions: [], paymentMethod: 'PIX', amountPaid: 0, installments: 1, termsAccepted: true
      },
      {
        fullName: 'Márcio Reis', birthDate: '1969-04-04', cpf: '16899535009', phone: '71998889900', email: 'marcio@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: '', specialNeeds: '', notes: '', roomPreference: '', groupName: 'Casais',
        accommodationType: 'suite_master', companions: ['Sônia Reis'], paymentMethod: 'Cartão', amountPaid: 6500, installments: 1, termsAccepted: true, checkInStatus: 'confirmado'
      },
      {
        fullName: 'Ester Brito', birthDate: '1999-02-12', cpf: '15350946056', phone: '71994441122', email: 'ester@exemplo.com', gender: 'Feminino',
        dietaryRestrictions: '', specialNeeds: '', notes: 'Aguardando liberação financeira.', roomPreference: '', groupName: 'Coral',
        accommodationType: 'triplo', companions: ['Ruth Brito', 'Sara Brito'], paymentMethod: 'Transferência', amountPaid: 0, installments: 3, termsAccepted: true
      },
      {
        fullName: 'Jonas Farias', birthDate: '1982-08-19', cpf: '46315591016', phone: '71993332211', email: 'jonas@exemplo.com', gender: 'Masculino',
        dietaryRestrictions: 'Diabético', specialNeeds: '', notes: 'Levará carro próprio.', roomPreference: '', groupName: 'Intercessão',
        accommodationType: 'quadruplo', companions: ['Paulo César', 'Renan Melo', 'Bruno Ramos'], paymentMethod: 'PIX', amountPaid: 6600, installments: 1,
        vehicle: { vehicleName: 'Sedan', driver: 'Jonas Farias', brand: 'Toyota', model: 'Corolla', plate: 'JFS4C27', color: 'Cinza', year: '2022' }, termsAccepted: true, checkInStatus: 'confirmado'
      }
    ];

    demoEntries.forEach((entry) => createRegistrationInternal(db, entry, 'Seeder', true));

    addAudit(db, 'Administrador Geral', 'Conciliação financeira', 'Relatórios iniciais preparados para a equipe financeira.');
    addAudit(db, 'Equipe Hospedagem', 'Mapa de ocupação atualizado', '82 unidades nomeadas por Flores, Frutas, Pássaros e Árvores.');
  };

  const ensureDb = () => {
    let db = loadDb();
    if (!db) {
      db = createBaseDb();
      seedDemoData(db);
      saveDb(db);
    }
    return db;
  };

  const init = () => ensureDb();

  const resetDemo = () => {
    const db = createBaseDb();
    seedDemoData(db);
    saveDb(db);
    return db;
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
  };

  const login = ({ profile, username, password, identifier }) => {
    const db = ensureDb();

    if (profile === 'retirante') {
      const normalized = String(identifier || '').trim();
      const digits = Utils.sanitizeDigits(normalized);
      const participant = db.participants.find((item) => item.cpf === digits || item.code.toUpperCase() === normalized.toUpperCase());
      if (!participant) return { ok: false, message: 'CPF ou código de inscrição não encontrado.' };
      const session = {
        role: 'retirante',
        participantId: participant.id,
        name: participant.fullName,
        code: participant.code,
        createdAt: nowIso()
      };
      saveSession(session);
      addAudit(db, participant.fullName, 'Login do retirante', participant.code);
      saveDb(db);
      return { ok: true, redirect: 'perfil.html', session };
    }

    const user = db.users.find((item) => item.role === profile && item.username === username && item.password === password);
    if (!user) return { ok: false, message: 'Credenciais inválidas para o perfil selecionado.' };

    const session = {
      role: user.role,
      userId: user.id,
      name: user.name,
      username: user.username,
      createdAt: nowIso()
    };
    saveSession(session);
    addAudit(db, user.name, 'Login administrativo', user.role);
    saveDb(db);
    return { ok: true, redirect: 'dashboard.html', session };
  };

  const getSession = () => loadSession();

  const getParticipantById = (participantId) => {
    const db = ensureDb();
    return clone(db.participants.find((item) => item.id === participantId) || null);
  };

  const getRegistrationByParticipantId = (participantId) => {
    const db = ensureDb();
    return clone(db.registrations.find((item) => item.participantId === participantId) || null);
  };

  const getVehicleByRegistrationId = (registrationId) => {
    const db = ensureDb();
    return clone(db.vehicles.find((item) => item.registrationId === registrationId) || null);
  };

  const updateParticipantPassword = (participantId, newPassword) => {
    const db = ensureDb();
    const participant = db.participants.find((item) => item.id === participantId);
    if (!participant) return { ok: false, message: 'Participante não encontrado.' };
    participant.appPassword = newPassword;
    addAudit(db, participant.fullName, 'Senha atualizada', participant.code);
    saveDb(db);
    return { ok: true, message: 'Senha atualizada com sucesso.' };
  };

  const getAccommodationStock = () => {
    const db = ensureDb();
    return Object.entries(ACCOMMODATIONS).map(([key, item]) => {
      const units = db.units.filter((unit) => unit.type === key);
      const occupiedUnits = item.mode === 'unit'
        ? units.filter((unit) => unit.occupants.length > 0).length
        : units.filter((unit) => unit.occupants.length > 0).length;
      const usedCapacity = units.reduce((sum, unit) => sum + unit.occupants.length, 0);
      const availableUnits = item.mode === 'unit'
        ? units.filter((unit) => unit.occupants.length === 0).length
        : units.filter((unit) => unit.occupants.length < unit.capacity).length;
      const waitlist = db.registrations.filter((registration) => registration.accommodationType === key && registration.reservationStatus === 'lista de espera').length;
      return {
        key,
        ...item,
        totalUnits: units.length,
        availableUnits,
        occupiedUnits,
        usedCapacity,
        waitlist,
        occupancyRate: item.mode === 'unit' ? Math.round((occupiedUnits / units.length) * 100) : Math.round((usedCapacity / item.capacity) * 100)
      };
    });
  };

  const submitRegistration = (payload) => {
    const db = ensureDb();
    const actor = payload.fullName || 'Inscrição web';
    const created = createRegistrationInternal(db, payload, actor, false);
    saveDb(db);
    return {
      ok: true,
      code: created.registration.code,
      participantId: created.participant.id,
      registration: clone(created.registration),
      participant: clone(created.participant),
      unit: clone(created.unit),
      message: created.registration.reservationStatus === 'lista de espera'
        ? 'Inscrição registrada em lista de espera para a acomodação escolhida.'
        : 'Inscrição concluída com sucesso.'
    };
  };

  const getParticipantProfile = (participantId) => {
    const db = ensureDb();
    const participant = db.participants.find((item) => item.id === participantId);
    const registration = db.registrations.find((item) => item.participantId === participantId);
    if (!participant || !registration) return null;
    const payments = db.payments.filter((payment) => payment.registrationId === registration.id);
    const unit = db.units.find((item) => item.id === registration.unitId) || null;
    const vehicle = db.vehicles.find((item) => item.registrationId === registration.id) || null;
    return clone({ participant, registration, payments, unit, vehicle });
  };

  const getDashboardData = () => {
    const db = ensureDb();
    const registrations = clone(db.registrations);
    const participants = clone(db.participants);
    const units = clone(db.units);
    const stock = getAccommodationStock();

    const totalRegistered = registrations.length;
    const totalConfirmed = registrations.filter((item) => item.reservationStatus === 'confirmada').length;
    const totalPending = registrations.filter((item) => item.paymentStatus === 'pagamento parcial' || item.paymentStatus === 'pendente').length;
    const waitlist = registrations.filter((item) => item.reservationStatus === 'lista de espera').length;
    const totalRevenue = Utils.sumBy(registrations, (item) => item.totalValue);
    const totalReceived = Utils.sumBy(db.payments, (item) => item.amount);
    const totalPendingAmount = Math.max(totalRevenue - totalReceived, 0);
    const totalVehicles = db.vehicles.length;

    const sexCount = participants.reduce((acc, item) => {
      acc[item.gender] = (acc[item.gender] || 0) + 1;
      return acc;
    }, {});

    const ageBands = { '0-17': 0, '18-29': 0, '30-44': 0, '45-59': 0, '60+': 0 };
    participants.forEach((item) => {
      const age = Utils.calculateAge(item.birthDate);
      if (age <= 17) ageBands['0-17'] += 1;
      else if (age <= 29) ageBands['18-29'] += 1;
      else if (age <= 44) ageBands['30-44'] += 1;
      else if (age <= 59) ageBands['45-59'] += 1;
      else ageBands['60+'] += 1;
    });

    const occupancyOverview = units.reduce((acc, unit) => {
      const occupancy = unit.occupants.length;
      if (occupancy === 0) acc.available += 1;
      else if (occupancy >= unit.capacity) acc.full += 1;
      else acc.partial += 1;
      return acc;
    }, { available: 0, partial: 0, full: 0 });

    const paymentMethodSummary = db.payments.reduce((acc, payment) => {
      acc[payment.method] = (acc[payment.method] || 0) + Number(payment.amount || 0);
      return acc;
    }, {});

    const mealDates = ['2027-02-05', '2027-02-06', '2027-02-07', '2027-02-08', '2027-02-09', '2027-02-10'];
    const activeParticipants = registrations.filter((item) => item.reservationStatus !== 'cancelada' && item.reservationStatus !== 'lista de espera');
    const mealSummary = mealDates.map((date) => ({
      date,
      cafe: activeParticipants.length,
      almoco: activeParticipants.length,
      jantar: activeParticipants.length,
      lanches: activeParticipants.length,
      especiais: participants.filter((item) => item.dietaryRestrictions).length
    }));

    const recentRegistrations = registrations
      .slice()
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 8)
      .map((registration) => {
        const participant = participants.find((item) => item.id === registration.participantId);
        const unit = units.find((item) => item.id === registration.unitId);
        return {
          ...registration,
          participantName: participant?.fullName || '—',
          phone: participant?.phone || '',
          unitName: unit?.name || 'Não alocado'
        };
      });

    const reports = {
      inadimplentes: registrations.filter((item) => item.pendingBalance > 0).length,
      quitadas: registrations.filter((item) => item.paymentStatus === 'quitada').length,
      pcd: participants.filter((item) => item.specialNeeds).length,
      restricoes: participants.filter((item) => item.dietaryRestrictions).length
    };

    return {
      meta: clone(db.meta),
      stock,
      totals: {
        totalRegistered,
        totalConfirmed,
        totalPending,
        waitlist,
        totalRevenue,
        totalReceived,
        totalPendingAmount,
        totalVehicles
      },
      sexCount,
      ageBands,
      occupancyOverview,
      paymentMethodSummary,
      mealSummary,
      recentRegistrations,
      users: clone(db.users),
      units,
      vehicles: clone(db.vehicles),
      auditLogs: clone(db.auditLogs),
      registrations,
      participants,
      reports
    };
  };

  return {
    init,
    resetDemo,
    login,
    logout,
    getSession,
    getAccommodationStock,
    submitRegistration,
    getParticipantById,
    getRegistrationByParticipantId,
    getParticipantProfile,
    getDashboardData,
    getVehicleByRegistrationId,
    updateParticipantPassword,
    ACCOMMODATIONS,
    baseDates
  };
})();
